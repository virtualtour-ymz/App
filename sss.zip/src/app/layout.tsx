import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { getCurrentUser } from "@/lib/auth";
import { PwaRegister } from "@/components/shell/PwaRegister";

export const metadata: Metadata = {
  title: { default: "پرستاریار — یادگیری پرستاری به سبک دولینگو", template: "%s | پرستاریار" },
  description: "آموزش گام‌به‌گام پرستاری با سؤالات تعاملی، امتیاز، استریک و لیگ‌های رقابتی",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, title: "پرستاریار", statusBarStyle: "default" },
  icons: { icon: "/icons/icon.svg", apple: "/icons/icon-192.png" },
};

export const viewport: Viewport = {
  themeColor: "#4F46E5",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser().catch(() => null);
  const theme = user?.theme ?? "light";
  return (
    <html lang="fa" dir="rtl" className={theme === "dark" ? "dark" : ""} suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://cdn.jsdelivr.net" crossOrigin="anonymous" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" />
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('theme');var s=${JSON.stringify(Boolean(user))};if(!s&&t==='dark'){document.documentElement.classList.add('dark')}else if(!s&&t==='light'){document.documentElement.classList.remove('dark')}}catch(e){}})();`,
          }}
        />
      </head>
      <body className="antialiased">
        {children}
        <PwaRegister />
      </body>
    </html>
  );
}
