export default function Loading() {
  return (
    <div className="grid min-h-dvh place-items-center">
      <div className="text-center animate-pulse"><div className="text-6xl">📚</div><p className="mt-3 font-black text-muted">در حال آماده‌سازی سؤالات...</p></div>
    </div>
  );
}
