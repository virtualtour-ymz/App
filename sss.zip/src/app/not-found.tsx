import Link from "next/link";
export default function NotFound() {
  return (
    <main className="grid min-h-dvh place-items-center p-6 text-center">
      <div>
        <div className="text-7xl">🔍</div>
        <h1 className="mt-4 text-2xl font-black">صفحه پیدا نشد</h1>
        <Link href="/learn" className="btn btn-primary mt-6">بازگشت به خانه</Link>
      </div>
    </main>
  );
}
