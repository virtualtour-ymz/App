"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "./ThemeToggle";
import { logoutAction } from "@/lib/actions";

export const NAV_ITEMS = [
  { href: "/learn", label: "یادگیری", icon: "🏠" },
  { href: "/practice", label: "تمرین", icon: "🎯" },
  { href: "/leaderboard", label: "لیگ", icon: "🏆" },
  { href: "/friends", label: "دوستان", icon: "🤝" },
  { href: "/shop", label: "فروشگاه", icon: "💎" },
  { href: "/profile", label: "پروفایل", icon: "👤" },
];

export function Sidebar({ isAdmin }: { isAdmin: boolean }) {
  const pathname = usePathname();
  const items = isAdmin ? [...NAV_ITEMS, { href: "/admin", label: "مدیریت", icon: "🛠️" }] : NAV_ITEMS;
  return (
    <aside className="hidden lg:flex fixed right-0 top-0 h-dvh w-64 flex-col border-l-2 border-soft bg-[var(--bg)] px-4 py-6 z-40">
      <Link href="/learn" className="flex items-center gap-2 px-3 mb-6">
        <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] text-xl shadow-lg shadow-indigo-500/30">🩺</span>
        <span className="text-2xl font-black bg-gradient-to-l from-[#4F46E5] to-[#7C3AED] bg-clip-text text-transparent">پرستاریار</span>
      </Link>
      <nav className="flex flex-col gap-1">
        {items.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-4 rounded-2xl px-4 py-3 text-sm font-extrabold uppercase transition ${
                active
                  ? "border-2 border-[#84d8ff] bg-[#ddf4ff] text-[#1cb0f6] dark:bg-[#1f3a48] dark:border-[#1cb0f6]"
                  : "border-2 border-transparent text-muted hover:bg-soft"
              }`}
            >
              <span className="text-2xl">{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="mt-auto flex flex-col gap-1">
        <Link href="/settings" className={`flex items-center gap-4 rounded-2xl px-4 py-3 text-sm font-extrabold transition border-2 ${pathname === "/settings" ? "border-[#84d8ff] bg-[#ddf4ff] text-[#1cb0f6] dark:bg-[#1f3a48]" : "border-transparent text-muted hover:bg-soft"}`}>
          <span className="text-2xl">⚙️</span>
          <span>تنظیمات</span>
        </Link>
        <ThemeToggle />
        <form action={logoutAction}>
          <button type="submit" className="flex w-full items-center gap-4 rounded-2xl px-4 py-3 text-sm font-extrabold text-muted hover:bg-soft border-2 border-transparent">
            <span className="text-2xl">🚪</span>
            <span>خروج</span>
          </button>
        </form>
      </div>
    </aside>
  );
}

export function BottomNav() {
  const pathname = usePathname();
  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 border-t-2 border-soft bg-[var(--bg)] safe-bottom">
      <ul className="flex items-stretch justify-around">
        {NAV_ITEMS.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <li key={item.href} className="flex-1">
              <Link
                href={item.href}
                aria-label={item.label}
                className={`flex flex-col items-center justify-center py-2 gap-0.5 transition ${active ? "text-[#1cb0f6]" : "text-muted"}`}
              >
                <span className={`text-2xl leading-none rounded-xl px-3 py-1 ${active ? "bg-[#ddf4ff] dark:bg-[#1f3a48] border-2 border-[#84d8ff]" : ""}`}>{item.icon}</span>
                <span className="text-[10px] font-bold">{item.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
