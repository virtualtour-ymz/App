"use client";
import { useEffect, useState } from "react";
import { setThemeAction } from "@/lib/actions";

export function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("theme", next ? "dark" : "light"); } catch {}
    setThemeAction(next ? "dark" : "light");
  };
  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={dark ? "حالت روشن" : "حالت تاریک"}
      className={`flex items-center gap-3 rounded-2xl font-bold transition hover:bg-soft ${compact ? "p-2" : "px-4 py-3 w-full"}`}
    >
      <span className="text-2xl">{dark ? "☀️" : "🌙"}</span>
      {!compact && <span className="text-sm text-muted">{dark ? "حالت روشن" : "حالت تاریک"}</span>}
    </button>
  );
}
