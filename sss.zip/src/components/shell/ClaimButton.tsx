"use client";
import { useTransition } from "react";
import { claimChallengeAction } from "@/lib/actions";
import { celebrate } from "@/lib/effects";

export function ClaimButton({ id, claimed }: { id: number; claimed: boolean }) {
  const [pending, start] = useTransition();
  if (claimed) return <span className="text-xl" title="دریافت شد">✅</span>;
  return (
    <button
      type="button"
      disabled={pending}
      onClick={() => start(async () => { await claimChallengeAction(id); celebrate(); })}
      className="btn btn-primary !px-3 !py-1.5 !text-xs !rounded-xl animate-bounce-slow"
    >
      دریافت
    </button>
  );
}
