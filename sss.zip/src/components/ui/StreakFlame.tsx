export function StreakFlame({ active, size = "text-2xl" }: { active: boolean; size?: string }) {
  return (
    <span className={`${size} inline-block ${active ? "animate-flame" : "grayscale opacity-50"}`} aria-hidden>
      🔥
    </span>
  );
}
