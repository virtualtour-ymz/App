"use client";
import { useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { toPersianDigits } from "@/lib/dates";
import { CheckIcon, ChevronDownIcon, CrownIcon, EmojiIcon, LockIcon } from "@/components/icons/Icon";

type StationNode = {
  id: number;
  title: string;
  icon: string;
  questionCount: number;
  completed: boolean;
  crowns: number;
  bestScore: number;
  unlocked: boolean;
};
type TopicUnit = { id: number; title: string; description: string; stations: StationNode[] };

const OFFSETS = [0, 36, 52, 36, 0, -36, -52, -36];

export function LearningPath({ topics, color }: { topics: TopicUnit[]; color: string }) {
  const [openStation, setOpenStation] = useState<number | null>(null);

  const currentStationId = (() => {
    for (const t of topics) for (const s of t.stations) if (s.unlocked && !s.completed) return s.id;
    return null;
  })();
  const currentTopicIdx = topics.findIndex((t) => t.stations.some((s) => s.id === currentStationId));
  const [openTopics, setOpenTopics] = useState<Set<number>>(() => new Set(currentTopicIdx >= 0 ? [currentTopicIdx] : []));

  const toggleTopic = (ti: number) =>
    setOpenTopics((prev) => {
      const next = new Set(prev);
      if (next.has(ti)) next.delete(ti);
      else next.add(ti);
      return next;
    });

  return (
    <div className="flex flex-col gap-4 pb-10">
      {topics.map((topic, ti) => {
        const isOpen = openTopics.has(ti);
        const done = topic.stations.filter((s) => s.completed).length;
        return (
          <section key={topic.id} className="overflow-hidden rounded-2xl border-2 border-soft bg-soft">
            <button
              type="button"
              onClick={() => toggleTopic(ti)}
              aria-expanded={isOpen}
              className="flex w-full items-center justify-between gap-3 p-4 text-right"
            >
              <div className="min-w-0">
                <p className="text-xs font-bold text-muted">مبحث {toPersianDigits(ti + 1)}</p>
                <h2 className="text-lg font-black">{topic.title}</h2>
                {topic.description && <p className="mt-0.5 text-xs text-muted">{topic.description}</p>}
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className="rounded-full px-3 py-1 text-xs font-black text-white" style={{ background: color }}>
                  {toPersianDigits(done)}/{toPersianDigits(topic.stations.length)}
                </span>
                <ChevronDownIcon className={`h-5 w-5 text-muted transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
              </div>
            </button>

            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  key="content"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.32, ease: [0.4, 0, 0.2, 1] }}
                  className="overflow-hidden"
                >
                  <div className="flex w-full flex-col items-center gap-6 px-4 pt-4 pb-6">
                    {topic.stations.map((s, si) => {
                      const offset = OFFSETS[si % OFFSETS.length];
                      const isCurrent = s.id === currentStationId;
                      const bg = s.completed ? "#58cc02" : s.unlocked ? color : "#29384d";
                      const border = s.completed ? "#46a302" : s.unlocked ? shade(color) : "#1e293b";
                      const isStationOpen = openStation === s.id;
                      return (
                        <div key={s.id} className="flex w-full flex-col items-center">
                          <div className="flex flex-col items-center" style={{ transform: `translateX(${offset}px)` }}>
                            {isCurrent && (
                              <motion.div
                                initial={{ opacity: 0, y: 4 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="mb-2 rounded-full px-3 py-1 text-xs font-black uppercase text-white shadow"
                                style={{ background: color }}
                              >
                                شروع
                              </motion.div>
                            )}
                            <button
                              type="button"
                              disabled={!s.unlocked}
                              onClick={() => setOpenStation(isStationOpen ? null : s.id)}
                              className="node-btn"
                              style={{ background: bg, borderColor: border, boxShadow: isCurrent ? `0 0 0 6px ${color}33` : undefined }}
                              aria-label={s.title}
                            >
                              {s.completed ? (
                                <CheckIcon className="h-8 w-8 text-white" />
                              ) : s.unlocked ? (
                                <EmojiIcon name={s.icon} className="h-8 w-8 text-white" />
                              ) : (
                                <LockIcon className="h-7 w-7 text-muted opacity-60" />
                              )}
                              {s.completed && (
                                <span className="absolute -bottom-3 flex gap-0.5 text-xs">
                                  {[0, 1, 2].map((i) => (
                                    <CrownIcon key={i} className={`h-4 w-4 ${i < s.crowns ? "text-amber-400" : "text-muted opacity-40"}`} />
                                  ))}
                                </span>
                              )}
                            </button>
                          </div>
                          <AnimatePresence initial={false}>
                            {isStationOpen && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: "auto", opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.24, ease: [0.4, 0, 0.2, 1] }}
                                className="w-full overflow-hidden"
                              >
                                <div
                                  className="mx-auto mt-3 w-full max-w-xs rounded-2xl p-4 text-white shadow-2xl sm:max-w-sm"
                                  style={{ background: s.completed ? "#58cc02" : color }}
                                >
                                  <h3 className="inline-flex items-center gap-1.5 text-lg font-black">
                                    <EmojiIcon name={s.icon} className="h-5 w-5" /> {s.title}
                                  </h3>
                                  <p className="mt-1 text-xs opacity-90">
                                    {toPersianDigits(s.questionCount)} سؤال
                                    {s.completed && ` • بهترین نمره ${toPersianDigits(s.bestScore)}٪`}
                                  </p>
                                  <Link
                                    href={`/lesson/${s.id}`}
                                    className="mt-3 flex items-center justify-center rounded-2xl border-b-4 border-black/15 bg-white py-3 font-black uppercase transition-all active:translate-y-1 active:border-b-0"
                                    style={{ color: s.completed ? "#58cc02" : color }}
                                  >
                                    {s.completed ? "تمرین دوباره +۵ XP" : "شروع +۱۰ XP"}
                                  </Link>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>
        );
      })}
    </div>
  );
}

function shade(hex: string) {
  const n = parseInt(hex.replace("#", ""), 16);
  const r = Math.max(0, ((n >> 16) & 255) - 40);
  const g = Math.max(0, ((n >> 8) & 255) - 40);
  const b = Math.max(0, (n & 255) - 40);
  return `rgb(${r},${g},${b})`;
}
