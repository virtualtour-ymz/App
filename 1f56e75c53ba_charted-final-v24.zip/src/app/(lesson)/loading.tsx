import { LottieMascot } from "@/components/mascot/LottieMascot";
export default function Loading() {
  return (
    <div className="grid min-h-dvh place-items-center">
      <div className="text-center"><LottieMascot src="/mascot/thoughtful-diagnosis.json" className="mx-auto h-32 w-20 sm:h-36 sm:w-24" /><p className="mt-3 font-black text-muted">در حال آماده‌سازی سؤالات...</p></div>
    </div>
  );
}
