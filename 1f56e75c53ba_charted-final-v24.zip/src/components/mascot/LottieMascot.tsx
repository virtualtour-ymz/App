"use client";
import { useEffect, useState } from "react";
import Lottie from "lottie-react";

/**
 * Frame-based Lottie mascot. The JSON is loaded on demand from /public so it
 * stays out of the JS bundle. `src` points to a file under /public (e.g.
 * "/mascot/joyful-jump.json").
 */
export function LottieMascot({ src, className }: { src: string; className?: string }) {
  const [data, setData] = useState<object | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch(src)
      .then((r) => {
        if (!r.ok) throw new Error(String(r.status));
        return r.json();
      })
      .then((j) => {
        if (!cancelled) setData(j);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (data) {
    return (
      <Lottie
        animationData={data}
        loop
        autoplay
        className={className}
        rendererSettings={{ preserveAspectRatio: "xMidYMid meet" }}
      />
    );
  }

  // Skeleton placeholder while the JSON loads
  return (
    <span
      className={`block animate-pulse rounded-full bg-white/10 ${className ?? ""}`}
      aria-hidden={failed ? undefined : true}
    />
  );
}
