"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition, type ReactNode } from "react";
import {
  deleteCategoryAction,
  deleteStationAction,
  deleteTopicAction,
  moveCategoryAction,
  moveStationAction,
  moveTopicAction,
  renameCategoryAction,
  renameStationAction,
  renameTopicAction,
  toggleCategoryLockAction,
} from "@/lib/actions";
import { toPersianDigits } from "@/lib/dates";
import {
  ArrowDownIcon,
  ArrowUpIcon,
  CheckIcon,
  EmojiIcon,
  LockIcon,
  PencilIcon,
  TrashIcon,
  XIcon,
} from "@/components/icons/Icon";

type Cat = { id: number; title: string; color: string; icon: string; locked: boolean; order: number };
type Topic = { id: number; categoryId: number; title: string; order: number };
type Station = { id: number; topicId: number; title: string; icon: string; count: number; order: number };

function fd(entries: Record<string, string>) {
  const f = new FormData();
  for (const [k, v] of Object.entries(entries)) f.set(k, v);
  return f;
}

function IconBtn({ onClick, title, danger, disabled, children }: { onClick?: () => void; title: string; danger?: boolean; disabled?: boolean; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg border-2 border-soft text-muted transition disabled:cursor-not-allowed disabled:opacity-30 ${
        danger ? "hover:border-[#ff4b4b] hover:text-[#ff4b4b]" : "hover:border-[#2DD4BF] hover:text-[#2DD4BF]"
      }`}
    >
      {children}
    </button>
  );
}

/**
 * Inline title editor: pencil to enter edit mode, then check/cross to save
 * or cancel. Keeps the row compact and only touches the one title.
 */
function InlineRename({ initial, onSave }: { initial: string; onSave: (value: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(initial);
  if (!editing) {
    return <IconBtn onClick={() => { setValue(initial); setEditing(true); }} title="تغییر نام"><PencilIcon className="h-4 w-4" /></IconBtn>;
  }
  return (
    <span className="inline-flex items-center gap-1">
      <input
        value={value}
        autoFocus
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") { onSave(value); setEditing(false); }
          if (e.key === "Escape") setEditing(false);
        }}
        className="w-40 rounded-lg border-2 border-[#2DD4BF] bg-soft px-2 py-1 text-sm font-bold outline-none"
      />
      <IconBtn onClick={() => { onSave(value); setEditing(false); }} title="ذخیره"><CheckIcon className="h-4 w-4" /></IconBtn>
      <IconBtn onClick={() => setEditing(false)} title="انصراف" danger><XIcon className="h-4 w-4" /></IconBtn>
    </span>
  );
}

export function StructureManager({ categories, topics, stations }: { categories: Cat[]; topics: Topic[]; stations: Station[] }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  const run = (fn: () => Promise<unknown>) =>
    startTransition(async () => {
      await fn();
      router.refresh();
    });

  const confirmDelete = (label: string) => window.confirm(`${label} برای همیشه حذف شود؟ این کار قابل بازگشت نیست.`);

  return (
    <div className="flex flex-col gap-3">
      <p className="text-xs text-muted leading-relaxed">
        برای هر رشته می‌توانید قفل (حالت «به‌زودی»)، تغییر نام، جابجایی و حذف انجام دهید. حذف رشته، همهٔ مباحث و ایستگاه‌های آن را هم حذف می‌کند.
      </p>

      {categories.length === 0 && <p className="text-sm text-muted">هنوز رشته‌ای ساخته نشده است.</p>}

      {categories.map((c) => {
        const cTopics = topics.filter((t) => t.categoryId === c.id);
        return (
          <div key={c.id} className="card p-3">
            {/* category row */}
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl" style={{ background: `${c.color}22`, border: `2px solid ${c.color}55` }}>
                <EmojiIcon name={c.icon} className="h-5 w-5" style={{ color: c.color }} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-black" style={{ color: c.locked ? undefined : c.color }}>{c.title}</p>
                <p className="text-[11px] text-muted">{toPersianDigits(cTopics.length)} مبحث {c.locked ? "• قفل شده" : ""}</p>
              </div>
              {c.locked && <LockIcon className="h-4 w-4 text-amber-500" />}
              <IconBtn onClick={() => run(() => toggleCategoryLockAction(c.id))} title={c.locked ? "باز کردن قفل" : "قفل کردن (به‌زودی)"}>
                <LockIcon className={`h-4 w-4 ${c.locked ? "text-amber-500" : ""}`} />
              </IconBtn>
              <InlineRename initial={c.title} onSave={(v) => run(() => renameCategoryAction(null, fd({ id: String(c.id), title: v })))} />
              <IconBtn onClick={() => run(() => moveCategoryAction(c.id, "up"))} title="جابجایی به بالا"><ArrowUpIcon className="h-4 w-4" /></IconBtn>
              <IconBtn onClick={() => run(() => moveCategoryAction(c.id, "down"))} title="جابجایی به پایین"><ArrowDownIcon className="h-4 w-4" /></IconBtn>
              <IconBtn onClick={() => { if (confirmDelete(`رشتهٔ «${c.title}»`)) run(() => deleteCategoryAction(c.id)); }} title="حذف رشته" danger><TrashIcon className="h-4 w-4" /></IconBtn>
            </div>

            {/* topics */}
            {cTopics.length > 0 && (
              <div className="mt-2 mr-4 flex flex-col gap-1.5 border-r-2 border-soft pr-3">
                {cTopics.map((t) => {
                  const tStations = stations.filter((s) => s.topicId === t.id);
                  return (
                    <div key={t.id} className="rounded-xl bg-soft/60 p-2">
                      <div className="flex items-center gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold">{t.title}</p>
                          <p className="text-[11px] text-muted">{toPersianDigits(tStations.length)} ایستگاه</p>
                        </div>
                        <InlineRename initial={t.title} onSave={(v) => run(() => renameTopicAction(null, fd({ id: String(t.id), title: v })))} />
                        <IconBtn onClick={() => run(() => moveTopicAction(t.id, "up"))} title="جابجایی به بالا"><ArrowUpIcon className="h-4 w-4" /></IconBtn>
                        <IconBtn onClick={() => run(() => moveTopicAction(t.id, "down"))} title="جابجایی به پایین"><ArrowDownIcon className="h-4 w-4" /></IconBtn>
                        <IconBtn onClick={() => { if (confirmDelete(`مبحث «${t.title}»`)) run(() => deleteTopicAction(t.id)); }} title="حذف مبحث" danger><TrashIcon className="h-4 w-4" /></IconBtn>
                      </div>

                      {/* stations */}
                      {tStations.length > 0 && (
                        <div className="mt-1.5 mr-3 flex flex-col gap-1">
                          {tStations.map((s) => (
                            <div key={s.id} className="flex items-center gap-2 rounded-lg px-2 py-1 hover:bg-soft">
                              <EmojiIcon name={s.icon} className="h-4 w-4 shrink-0" />
                              <div className="min-w-0 flex-1">
                                <p className="truncate text-xs font-bold">{s.title}</p>
                                <p className="text-[10px] text-muted">#{s.id} • {toPersianDigits(s.count)} سؤال</p>
                              </div>
                              <InlineRename initial={s.title} onSave={(v) => run(() => renameStationAction(null, fd({ id: String(s.id), title: v })))} />
                              <IconBtn onClick={() => run(() => moveStationAction(s.id, "up"))} title="جابجایی به بالا"><ArrowUpIcon className="h-4 w-4" /></IconBtn>
                              <IconBtn onClick={() => run(() => moveStationAction(s.id, "down"))} title="جابجایی به پایین"><ArrowDownIcon className="h-4 w-4" /></IconBtn>
                              <IconBtn onClick={() => { if (confirmDelete(`ایستگاه «${s.title}»`)) run(() => deleteStationAction(s.id)); }} title="حذف ایستگاه" danger><TrashIcon className="h-4 w-4" /></IconBtn>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}

      {isPending && <p className="text-xs font-bold text-[#2DD4BF]">در حال ذخیره…</p>}
    </div>
  );
}
