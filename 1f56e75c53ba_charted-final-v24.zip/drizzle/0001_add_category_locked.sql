-- Adds the `locked` flag to categories, used for the "coming soon" state.
ALTER TABLE "categories" ADD COLUMN IF NOT EXISTS "locked" boolean NOT NULL DEFAULT false;
