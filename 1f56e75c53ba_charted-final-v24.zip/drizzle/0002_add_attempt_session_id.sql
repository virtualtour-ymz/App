-- Tags each answer attempt with the lesson session it belongs to, so session
-- accuracy can be computed precisely (no "latest N attempts" heuristic).
ALTER TABLE "attempts" ADD COLUMN IF NOT EXISTS "session_id" varchar(64);
